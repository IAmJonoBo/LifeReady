# Roadmap

## Track A

- Rust workspace + service crates
- Local dev environment (Postgres)
- Migrations wiring

## Track B

- Audit hash-chain persistence
- Contract tests expansion
- Pack generation workflows

## Track C

- Flutter feature screens
- Role invitations, document upload, case flows
