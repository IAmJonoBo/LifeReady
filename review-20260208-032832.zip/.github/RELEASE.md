# Release Process

1. Update CHANGELOG.md.
2. Tag the release: git tag -a vX.Y.Z -m "Release vX.Y.Z".
3. Push tags: git push --tags.
4. Create a GitHub Release with notes from CHANGELOG.md.
